package com.igate.irs.service;


import com.igate.irs.dto.User;
import com.igate.irs.exception.IRSLoginException;

public interface ILoginService {
	User isValidUser(User user) throws IRSLoginException;
}
