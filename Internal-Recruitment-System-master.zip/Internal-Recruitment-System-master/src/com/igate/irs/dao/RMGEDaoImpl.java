package com.igate.irs.dao;


import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.igate.irs.dto.Requisition;
import com.igate.irs.dto.Suggestion;
import com.igate.irs.exception.IRSRMGEException;

@Component("rmgedao")
public class RMGEDaoImpl implements IRMGEDao{
	
	@Autowired
	DataSource datasource;
	
	public DataSource getDatasource() {
		return datasource;
	}

	public void setDatasource(DataSource datasource) {
		this.datasource = datasource;
	}
	
	@Override
	public List<Requisition> viewRequestions() throws IRSRMGEException
	{	
		try{
			String sql="select * from REQUISITION Where CURRENT_STATUS='OPEN'";
			JdbcTemplate jdbcTemplet=new JdbcTemplate(datasource);
			List<Requisition> requistion=jdbcTemplet.query(sql, new RequisitionRowMapper());
			System.out.println(requistion);
			return requistion;
		}
		catch(DataAccessException e)
		{
			throw new IRSRMGEException(e.getMessage());
		}
		
	}

	public List<Object[]> viewSearch(String rskill,String rdomain,String rid) throws IRSRMGEException
	{
		String sql="select R.REQUISITION_ID,E.EMPLOYEE_ID, E.EMPLOYEE_NAME, E.PROJECT_ID, E.SKILL, E.DOMAIN, E.EXPERIENCE_YRS from EMPLOYEE E, REQUISITION R WHERE E.PROJECT_ID='RMG' AND R.DOMAIN=E.DOMAIN AND R.SKILL=E.SKILL AND R.CURRENT_STATUS='OPEN' AND R.SKILL='"+rskill+"' AND R.DOMAIN='"+rdomain+"'AND R.REQUISITION_ID='"+rid+"' AND E.EMPLOYEE_ID NOT IN (SELECT EMPLOYEE_ID FROM SUGGESTIONS)";
		JdbcTemplate jdbcTemplate=new JdbcTemplate(datasource);
		List<Object[]> empList=jdbcTemplate.query(sql, new ObjectRowMapper());
		System.out.println("sql is:"+sql);
		System.out.println("view search list........"+empList);
		if(empList.size()>0)
		{
			return empList;
		}
		else
		{
		return null;
		}
	}

	@Override
	public boolean suggestEmployee(Suggestion suggestion)
			throws IRSRMGEException {
		boolean flag=false;
		try
		{
		String sql = "INSERT INTO SUGGESTIONS VALUES(?,?)";
		JdbcTemplate jdbcTemplate=new JdbcTemplate(datasource);
		Object[] obj=new Object[]{suggestion.getRequisitionId(),suggestion.getEmployeeId()};
		int count=jdbcTemplate.update(sql, obj);
		if(count==1)
		{
			flag=true;
		}
		else
		{
			flag=false;
		}
		return flag;
		}
		catch (DataAccessException e) {
			e.printStackTrace();
			throw new IRSRMGEException(e.getMessage());
		}
	}
	@Override
	public List<Requisition> generateReport(String status) throws IRSRMGEException
	{
		try
		{
			String sql="select * from REQUISITION WHERE CURRENT_STATUS ='"+status+"'";
			JdbcTemplate jdbcTemplet=new JdbcTemplate(datasource);
			List<Requisition> requistion=jdbcTemplet.query(sql, new RequisitionRowMapper());
			System.out.println(requistion);
			return requistion;
		}
		catch (DataAccessException e) {
			e.printStackTrace();
			throw new IRSRMGEException(e.getMessage());
		}
		
		
	}

}
