package com.igate.irs.exception;

public class IRSRMGEException extends Exception {

	public IRSRMGEException(String msg) {
		super(msg);
	}
}
