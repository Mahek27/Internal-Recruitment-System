package com.igate.irs.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.igate.irs.dto.Requisition;
import com.igate.irs.dto.Suggestion;
import com.igate.irs.exception.IRSRMException;
import com.igate.irs.service.IRMService;

@Controller
@RequestMapping(value="/RM")
public class RMController {

	@Autowired
	IRMService rmService;

	@RequestMapping(value="/RaiseRequistion",method=RequestMethod.GET)
	public String showRaiseRequistionPage(HttpSession session, Model model){

		String validUser = (String) session.getAttribute("validUser");
		if(validUser == null){
			return "redirect:../Login/loginPage";
		}
		String rmId = (String) session.getAttribute("userid"); 

		String raised = (String) session.getAttribute("raised");
		System.out.println("Raised:"+raised);
		model.addAttribute("raised",raised);
		if(raised!=null)
			session.removeAttribute("raised");

		try {
			List<String> projects = rmService.getRMProjects(rmId);
			String[] project = new String[projects.size()];
			String[] domain  = new String[projects.size()];

			int i=0;
			for(String s:projects){
				String[] str = s.split("-");
				project[i]  = str[0] + " - " + str[1];
				domain[i++] = str[2];
			}

			model.addAttribute("projectdomain",projects);
			model.addAttribute("projects", project);
			model.addAttribute("domains", domain);

		} catch (IRSRMException e) {
			model.addAttribute("errMsg", e.getMessage());
			return "error";
		}
		return "rmRaiseRequisition";		
	}

	@RequestMapping(value="/ViewRequisitions",method=RequestMethod.GET)
	public String showViewRequisitionsPage(HttpSession session,Model model){

		String validUser = (String) session.getAttribute("validUser");
		if(validUser == null){
			return "redirect:../Login/loginPage";
		}
		
		String rmId = (String) session.getAttribute("userid"); 
		try {
			List<Requisition> requisitions = rmService.getAllRequisitions(rmId);
			model.addAttribute("requisitions", requisitions);
		} catch (IRSRMException e) {
			model.addAttribute("errMsg", e.getMessage());
			return "error";
		}
		return "rmViewRequisitions";		
	}


	@RequestMapping(value="/ViewSuggestions",method=RequestMethod.GET)
	public String showViewSuggestionsPage(HttpSession session,Model model){
		
		String validUser = (String) session.getAttribute("validUser");
		if(validUser == null){
			return "redirect:../Login/loginPage";
		}
		
		String rmId = (String) session.getAttribute("userid");

		String accepted = (String) session.getAttribute("accepted");
		String declined = (String) session.getAttribute("declined");
		System.out.println(accepted +"-"+ declined);
		model.addAttribute("accepted",accepted);
		model.addAttribute("declined",declined);

		if(accepted!=null)
			session.removeAttribute("accepted");

		if(declined!=null)
			session.removeAttribute("declined");

		try {
			List<Object[]> suggestions = rmService.getSuggestions(rmId);
			if(suggestions!=null){
				System.out.println("suggesstions available");
			}	
			model.addAttribute("suggestions", suggestions);
		} catch (IRSRMException e) {
			model.addAttribute("errMsg", e.getMessage());
			return "error";
		}
		return "rmViewSuggestions";		
	}

	@RequestMapping(value="/GenerateReport",method=RequestMethod.GET)
	public String showGenerateReportPage(HttpSession session){
		String validUser = (String) session.getAttribute("validUser");
		if(validUser == null){
			return "redirect:../Login/loginPage";
		}
		
		return "rmGenerateReport";		
	}

	@RequestMapping(value="/ViewEmployees",method=RequestMethod.GET)
	public String showViewEmployeesPage(
			HttpSession session,
			Model model){

		String validUser = (String) session.getAttribute("validUser");
		if(validUser == null){
			return "redirect:../Login/loginPage";
		}
		
		String rmId = (String) session.getAttribute("userid");

		try {
			List<Object[]> employeeList = rmService.getRMEmployeeDetails(rmId);
			if(employeeList!=null){
				System.out.println("employees available under him\n" +employeeList);
			}
			else{
				System.out.println("employees not available under him");
			}
			model.addAttribute("employeeList",employeeList);
		} catch (IRSRMException e) {
			model.addAttribute("errMsg", e.getMessage());
			return "error";
		}
		return "rmViewEmployees";		
	}


	@RequestMapping(value="/raiseRequisition",method=RequestMethod.POST)
	public String raiseNewRequisition(
			HttpSession session,
			Model model,
			@RequestParam("project") String project,
			@RequestParam("domain") String domain,
			@RequestParam("vacancyName") String vacancyName,
			@RequestParam("skill") String skill,
			@RequestParam("noOfWorkforce") String noOfWorkforce){

		String validUser = (String) session.getAttribute("validUser");
		if(validUser == null){
			return "redirect:../Login/loginPage";
		}
		
		String projectId = project.split("-")[0];
		String rmId = (String) session.getAttribute("userid"); 
		Requisition req = new Requisition();
		req.setRmId(rmId);
		req.setProjectId(projectId);
		req.setVacancyName(vacancyName);
		req.setSkill(skill);
		req.setDomain(domain);
		req.setNumberRequired(noOfWorkforce);

		int isRaised;
		try {
			isRaised = rmService.raiseRequisition(req);
			if(isRaised==1){
				System.out.println("requisition raised successfully");
				session.setAttribute("raised","true");
			}
		} catch (IRSRMException e) {
			model.addAttribute("errMsg", e.getMessage());
			return "error";
		}
		System.out.println(isRaised);

		return "redirect:/RM/RaiseRequistion";		
	}


	@RequestMapping(value="/acceptSuggestion",method=RequestMethod.GET)
	public String acceptSuggestion(
			HttpSession session,
			Model model,
			@RequestParam("employeeId") String employeedId,
			@RequestParam("requisitionId") String requisitionId,
			@RequestParam("projectSuggestedFor") String projectSuggestedFor){

		String validUser = (String) session.getAttribute("validUser");
		if(validUser == null){
			return "redirect:../Login/loginPage";
		}
		
		Suggestion suggestion = new Suggestion();
		suggestion.setEmployeeId(employeedId);
		suggestion.setRequisitionId(requisitionId);

		try {
			if(rmService.acceptSuggestion(suggestion, projectSuggestedFor)){
				System.out.println("Suggestion accepted");
				session.setAttribute("accepted","true");
			}
			else{
				System.out.println("Suggestion not accepted");
			}
		} catch (IRSRMException e) {
			model.addAttribute("errMsg", e.getMessage());
			return "error";
		}
		return "redirect:/RM/ViewSuggestions";
	}

	@RequestMapping(value="/declineSuggestion",method=RequestMethod.GET)
	public String declineSuggestion(
			HttpSession session,
			Model model,
			@RequestParam("employeeId") String employeeId,
			@RequestParam("requisitionId") String requisitionId){

		String validUser = (String) session.getAttribute("validUser");
		if(validUser == null){
			return "redirect:../Login/loginPage";
		}
		
		Suggestion suggestion = new Suggestion();
		suggestion.setEmployeeId(employeeId);
		suggestion.setRequisitionId(requisitionId);

		try {
			if(rmService.declineSuggestion(suggestion)){
				System.out.println("Suggestion declined");
				session.setAttribute("declined","true");
			}
			else{
				System.out.println("Suggestion not declined");
			}
		} catch (IRSRMException e) {
			model.addAttribute("errMsg", e.getMessage());
			return "error";
		}
		return "redirect:/RM/ViewSuggestions";
	}


	@RequestMapping(value="/generateReport",method=RequestMethod.GET)
	public String generateReport(
			Model model,
			HttpSession session,
			@RequestParam("status") String status){

		String validUser = (String) session.getAttribute("validUser");
		if(validUser == null){
			return "redirect:../Login/loginPage";
		}
		
		String rmId = (String) session.getAttribute("userid");

		try {
			List<Requisition> requisitions = rmService.generateReport(status, rmId);
			System.out.println("Report list \n" + requisitions);
			model.addAttribute("requisitions",requisitions);
		} catch (IRSRMException e) {
			model.addAttribute("errMsg", e.getMessage());
			return "error";
		}
		return "rmGenerateReport";
	}


	@RequestMapping(value="/changeProjectId",method=RequestMethod.GET)
	public String changeProjectId(
			Model model,
			HttpSession session,
			@RequestParam("employeeId") String employeeId){

		String validUser = (String) session.getAttribute("validUser");
		if(validUser == null){
			return "redirect:../Login/loginPage";
		}
		
		try {
			if(rmService.changeEmployeeProject(employeeId)){
				System.out.println("employee "+employeeId+" projectId updated to RMG");
			}
			else{
				System.out.println("employee "+employeeId+" projectId not updated to RMG");
			}
		} catch (IRSRMException e) {
			model.addAttribute("errMsg", e.getMessage());
			return "error";
		}
		return "redirect:/RM/ViewEmployees";
	}

}
