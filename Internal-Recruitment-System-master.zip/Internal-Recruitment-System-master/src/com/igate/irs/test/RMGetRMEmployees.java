package com.igate.irs.test;

import static junit.framework.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.igate.irs.dao.RMDaoImpl;
import com.igate.irs.exception.IRSRMException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"dispatcher-servlet.xml"})
public class RMGetRMEmployees {
	
	@Autowired
	private RMDaoImpl rmDao;

	//giving valid rmID AP835017 who has some suggestions
	@Test
	public void test1() {
		System.out.println("in test class 1");
		
		try {
			assertNotNull(rmDao.getRMEmployeeDetails("AP835017"));
		} catch (IRSRMException e) {
			e.printStackTrace();
		}
	}
	
	//giving valid rmID RP852468 who has no suggestions
	@Test
	public void test2() {
		System.out.println("in test class 2");
		
		try {
			assertNotNull(rmDao.getRMEmployeeDetails("RP852468"));
		} catch (IRSRMException e) {
			e.printStackTrace();
		}
	}
	

}
