package com.igate.irs.exception;

public class IRSLoginException extends Exception {

	public IRSLoginException(String msg) {
		super(msg);
	}
}
