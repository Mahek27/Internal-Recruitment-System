package com.igate.irs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ProjectRowMapper implements RowMapper<String>{

	@Override
	public String mapRow(ResultSet rst, int num) throws SQLException {
		String project = rst.getString("project_id") + "-" + rst.getString("project_name") + "-" + rst.getString("domain");
		return project;
	}

}
