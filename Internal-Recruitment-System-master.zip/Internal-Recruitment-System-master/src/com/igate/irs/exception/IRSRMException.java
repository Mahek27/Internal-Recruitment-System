package com.igate.irs.exception;

public class IRSRMException extends Exception {

	public IRSRMException(String msg) {
		super(msg);
	}
}
