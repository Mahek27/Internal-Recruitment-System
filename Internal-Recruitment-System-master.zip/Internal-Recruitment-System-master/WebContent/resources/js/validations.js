function validateLogin(form)
{

	var username = form.userId.value;
	var password = form.password.value;
	var loginError = document.getElementById("loginError");
	var nameReg = new RegExp("[A-Z]{2}[0-9]{6}");
	
	var flag = true;
	
	if(username == null || username == ""){
		loginError.innerHTML = "*Please Enter Username";
		flag = false;
	}
	else if(!username.match(nameReg)){
		loginError.innerHTML="*Invalid Username";
		flag = false;	
	}
	else if(password == null || password == ""){
		loginError.innerHTML = "*Please Enter Password";
		flag = false;
	}
	else{
		loginError.innerHTML = "";
	}
	
	return flag;
}

function validateWorkforce(form)
{
	var nameReg = new RegExp("^[1-9]{1}[0-9]?$");
	var vacancyReg = new RegExp("^[a-zA-Z/s]+$");
	var project   	= form.project.value;
	var skill   	= form.skill.value;
	var workforce 	= form.noOfWorkforce.value;
	var vacancy 	= form.vacancyName.value;
	var vacancyError = document.getElementById("vacancyName");
	var workforceError = document.getElementById("workforce");
	var projectError = document.getElementById("project");
	var skillError = document.getElementById("skill");
	
	var flag = true;
	
	if(vacancy == null || vacancy == ""){
		vacancyError.innerHTML = " *Please Enter the Vacancy Name";
		flag = false;
	}
	else if(!vacancy.match(vacancyReg))
	{
			
		vacancyError.innerHTML=" *No numbers or special characters should come";
		flag=false;
	}
	else {
		vacancyError.innerHTML = "";
	}
	
	if(project == null || project == ""){
		projectError.innerHTML = " *Please Select a Project";
		flag = false;
	}
	else {
		projectError.innerHTML = "";
	}
	
	if(skill == null || skill == ""){
		skillError.innerHTML = " *Please Enter the Skill";
		flag = false;
	}
	else {
		skillError.innerHTML = "";
	}
	
	if(workforce == null || workforce == ""){
		workforceError.innerHTML = " *Please Enter a Value";
		flag = false;
	}
	else if(!workforce.match(nameReg))
	{
			
		workforceError.innerHTML=" *Invalid Workforce";
		flag=false;
	}
	else{
		
		workforceError.innerHTML = "";
	}
	return flag;
}


function validatePassword(form)
{
	var flag = true;
	var password = form.password.value;
	var passwordError = document.getElementById("password");
	var passReg = new RegExp("^[A-Za-z0-9]{3,15}$");
	
	if(password == null || password == ""){
		passwordError.innerHTML = " *Please Enter Password";
		flag = false;
	}
	else if(!password.match(passReg)){
		passwordError.innerHTML=" *Password must be 3 to 15 characters long";
		flag = false;	
	}
	else{
		passwordError.innerHTML = "";
	}
	
	return flag;
}

function setDomain(form){
	var domain = form.domain;
	var selectedIndex = form.project.selectedIndex;
	var value    = form.project.value;
	var str      = value.split("-");
	domain.value = str[2];
	
}