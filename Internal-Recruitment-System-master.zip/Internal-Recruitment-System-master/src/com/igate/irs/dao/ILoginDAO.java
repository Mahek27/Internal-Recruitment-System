package com.igate.irs.dao;

import com.igate.irs.dto.User;
import com.igate.irs.exception.IRSLoginException;

public interface ILoginDAO {
	User isValidUser(User user) throws IRSLoginException;
}
