package com.igate.irs.exception;

public class IRSAdminException extends Exception {

	public IRSAdminException(String msg) {
		super(msg);
	}
}
