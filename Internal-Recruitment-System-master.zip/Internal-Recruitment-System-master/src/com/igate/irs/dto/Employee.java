package com.igate.irs.dto;

public class Employee {

	private String employeeId;
	private String employeeName;
	private String projectId;
	private String skill;
	private String domain;
	private int experienceYears;
	
	public Employee() {
		
	}
	
	public Employee(String employeeId, String employeeName, String projectId,
			String skill, String domain, int experienceYears) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.projectId = projectId;
		this.skill = skill;
		this.domain = domain;
		this.experienceYears = experienceYears;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getSkill() {
		return skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public int getExperienceYears() {
		return experienceYears;
	}

	public void setExperienceYears(int experienceYears) {
		this.experienceYears = experienceYears;
	}

	
	
}
