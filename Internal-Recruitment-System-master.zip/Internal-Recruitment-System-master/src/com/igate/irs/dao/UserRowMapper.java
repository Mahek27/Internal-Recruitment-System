package com.igate.irs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.igate.irs.dto.User;

public class UserRowMapper implements RowMapper<User> {

	@Override
	public User mapRow(ResultSet resultSet, int num) throws SQLException {
		User user=new User();
		user.setUserId(resultSet.getString("user_id"));
		user.setUserName(resultSet.getString("employee_name"));
		user.setPassword(resultSet.getString("password"));
		user.setRole(resultSet.getString("role"));
		return user;
	}

}
