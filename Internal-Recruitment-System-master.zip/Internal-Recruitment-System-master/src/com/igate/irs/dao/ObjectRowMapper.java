package com.igate.irs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ObjectRowMapper implements RowMapper<Object[]>{

	@Override
	public Object[] mapRow(ResultSet resultSet, int num)
			throws SQLException {
		Object[] object=new Object[7];
		object[0]=resultSet.getString("EMPLOYEE_ID");
		object[1]=resultSet.getString("EMPLOYEE_NAME");
		object[2]=resultSet.getString("PROJECT_ID");
		object[3]=resultSet.getString("SKILL");
		object[4]=resultSet.getString("DOMAIN");
		object[5]=resultSet.getInt("EXPERIENCE_YRS");
		object[6]=resultSet.getString("REQUISITION_ID");
		return object;
	}

	

}
