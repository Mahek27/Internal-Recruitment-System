package com.igate.irs.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.igate.irs.dto.User;
import com.igate.irs.exception.IRSLoginException;
@Component("logindao")
public class LoginDAOImpl implements ILoginDAO {
	@Autowired
	DataSource datasource;
	
	
	@Override
	public User isValidUser(User user) throws IRSLoginException 
	{
		String sql = "SELECT u.user_id, u.password, u.role, employee_name FROM user1 u, employee e WHERE user_id=? AND password=? AND role=? AND e.employee_id=u.user_id";
		JdbcTemplate jdbc=new JdbcTemplate(datasource);
		Object[] obj={user.getUserId(),user.getPassword(),user.getRole()};
		List<User> u = jdbc.query(sql, obj, new UserRowMapper());
		if(u.size()>0){
			return u.get(0);
		}
		return null;
	}
	
}
