package com.igate.irs.test;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.igate.irs.dao.RMGEDaoImpl;
import com.igate.irs.exception.IRSRMGEException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"dispatcher-servlet.xml"})
@ActiveProfiles("oracle")
public class RMGESearchTest {
	
	@Autowired
	private RMGEDaoImpl rmgeDao;

	@Test
	public void testForSearch() {
		System.out.println("in test class1");
		String rskill="Level 5";
		String rdomain=".Net";
		String rid="RQ045";
		try {
			Assert.assertNotNull(rmgeDao.viewSearch(rskill, rdomain, rid));
		} catch (IRSRMGEException e) {
			e.printStackTrace();
		}
	}
	@Test
	public void testForSearchNull() {
		System.out.println("in test class1");
		String rskill="Level 10";
		String rdomain="Java";
		String rid="RQ045";
		try {
			Assert.assertNull(rmgeDao.viewSearch(rskill, rdomain, rid));
		} catch (IRSRMGEException e) {
			e.printStackTrace();
		}
	}
}
