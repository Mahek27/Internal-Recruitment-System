package com.igate.irs.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.igate.irs.dto.Requisition;
import com.igate.irs.dto.Suggestion;
import com.igate.irs.exception.IRSRMGEException;
import com.igate.irs.service.RMGEServiceImpl;

@Controller
@RequestMapping(value="/RMGE")
public class RMGEController {

	@Autowired
	RMGEServiceImpl rmgeService;

	@RequestMapping(value="/viewRequisitions",method=RequestMethod.GET)
	public String rmgeViewRequisition(HttpSession session, Model model)
	{
		String validUser = (String) session.getAttribute("validUser");
		if(validUser == null){
			return "redirect:../Login/loginPage";
		}
		
		try {
			System.out.println("In Controller... view Requisition");
			List<Requisition> requisitionsList=rmgeService.viewRequestions();
			model.addAttribute("reqList", requisitionsList);
			return "rmgeViewRequsition";
			//return new ModelAndView("rmgeViewRequsition","reqList",requisitionsList);

		} catch (IRSRMGEException e) {
			model.addAttribute("errMsg",e.getMessage());
			return "error";
		}
	}
	@RequestMapping(value="/search",method=RequestMethod.GET)
	public String Search(HttpSession session,@RequestParam("skill") String rSkill,@RequestParam("domain") String rDomain,@RequestParam("requisitionId") String rId,Model model,Map<String,Object> map)
	{
		String validUser = (String) session.getAttribute("validUser");
		if(validUser == null){
			return "redirect:../Login/loginPage";
		}
		
		try {
			List<Object[]> empList=rmgeService.viewSearch(rSkill,rDomain,rId);
			map.put("list", empList);
			return "rmgeSearchAndSuggestion";
		} catch (IRSRMGEException e) {
			model.addAttribute("errMsg",e.getMessage());
			return "error";
		}

	}
	@RequestMapping(value="/suggest",method=RequestMethod.POST)
	public String Suggest(HttpSession session,@ModelAttribute Suggestion suggestion,@RequestParam("skill") String rSkill,@RequestParam("domain") String rDomain,@RequestParam("requisitionId") String rId,@RequestParam("empID") String empId,Model model,Map<String,Object> map)
	{	
		String validUser = (String) session.getAttribute("validUser");
		if(validUser == null){
			return "redirect:../Login/loginPage";
		}
		
		System.out.println(suggestion.getRequisitionId());
		suggestion.setRequisitionId(rId);
		suggestion.setEmployeeId(empId);
		try 
		{
			boolean suggest=rmgeService.suggestEmployee(suggestion);
			if(suggest==true)
			{
				System.out.println("suggested");
				model.addAttribute("suggested", "true");
			}
			else
			{
				System.out.println(" not suggested");
			}
			List<Object[]> empList=rmgeService.viewSearch(rSkill,rDomain,rId);
			map.put("list", empList);
			return "rmgeSearchAndSuggestion";
		} catch (IRSRMGEException e) 
		{
			model.addAttribute("errMsg","Employee is already suggested");
			return "error";
		}
	}


	@RequestMapping(value="/generateReport")
	public String generateReport(HttpSession session,Model model)
	{
		String validUser = (String) session.getAttribute("validUser");
		if(validUser == null){
			return "redirect:../Login/loginPage";
		}
		
		Requisition requisitionStatus=new Requisition();
		List<String> status=new ArrayList<String>();
		status.add("OPEN");
		status.add("CLOSED");
		model.addAttribute("requisition",requisitionStatus);
		model.addAttribute("status", status);
		return "rmgeGenerateReport";

	}

	@RequestMapping(value="/displayGenerateReport")
	public String displayGenerateReport(HttpSession session,@ModelAttribute("requisition") Requisition req,@RequestParam("currentStatus") String status,Model model,Map<String,Object> map)
	{
		String validUser = (String) session.getAttribute("validUser");
		if(validUser == null){
			return "redirect:../Login/loginPage";
		}
		
		System.out.println("Status is:"+status);
		try {
			List<Requisition> requisitionList=rmgeService.generateReport(status);
			System.out.println("requisition list for report::"+requisitionList);
			map.put("requisitions",requisitionList);
			List<String> status1=new ArrayList<String>();
			status1.add("OPEN");
			status1.add("CLOSED");
			model.addAttribute("requisition",req);
			model.addAttribute("status", status1);
		}
		catch (IRSRMGEException e) {
			model.addAttribute("errMsg",e.getMessage());
			return "error";
		}
		return "rmgeGenerateReport";

	}

}
