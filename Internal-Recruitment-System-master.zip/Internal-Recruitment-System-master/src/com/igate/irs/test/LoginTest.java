package com.igate.irs.test;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.igate.irs.dao.LoginDAOImpl;
import com.igate.irs.dto.User;
import com.igate.irs.exception.IRSLoginException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"dispatcher-servlet.xml"})
@ActiveProfiles("oracle")
public class LoginTest {
	
	@Autowired
	private LoginDAOImpl logindao;

	//giving valid details
	@Test
	public void test1() {
		System.out.println("in test class1");
		User user = new User();
		user.setUserId("AP835017");user.setPassword("aditi");
		user.setRole("rm");
		try {
			Assert.assertNotNull(logindao.isValidUser(user));
		} catch (IRSLoginException e) {
			e.printStackTrace();
		}
	}
	
	//giving invalid details
	@Test
	public void testReportForClose() {
		System.out.println("in test class2");
		User user = new User();
		user.setUserId("AP835017");user.setPassword("adhi");
		user.setRole("rm");
		try {
			Assert.assertNotNull(logindao.isValidUser(user));
		} catch (IRSLoginException e) {
			e.printStackTrace();
		}
	}
}
