package com.igate.irs.service;

import java.util.List;

import com.igate.irs.dto.Requisition;
import com.igate.irs.dto.Suggestion;
import com.igate.irs.exception.IRSRMGEException;

public interface IRMGEService {

	List<Requisition> viewRequestions() throws IRSRMGEException;
	List<Object[]> viewSearch(String rskill,String rdomain,String rid) throws IRSRMGEException;
	boolean suggestEmployee(Suggestion suggestion) throws IRSRMGEException;
	List<Requisition> generateReport(String status) throws IRSRMGEException;
}
