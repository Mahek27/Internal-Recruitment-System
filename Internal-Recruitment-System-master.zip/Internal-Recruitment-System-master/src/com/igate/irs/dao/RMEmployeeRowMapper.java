package com.igate.irs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;

import org.springframework.jdbc.core.RowMapper;

public class RMEmployeeRowMapper implements RowMapper<Object[]> {

	@Override
	public Object[] mapRow(ResultSet rst, int num) throws SQLException {
		Object obj[] = new Object[7];
		obj[0] = rst.getString("employee_id");
		obj[1] = rst.getString("employee_name");
		obj[2] = rst.getString("project_id");
		obj[3] = rst.getString("project_name");
		obj[4] = rst.getDate("start_date").toLocalDate();
		obj[5] = rst.getDate("end_date").toLocalDate();
		Period  p = Period.between(LocalDate.now(), (LocalDate)obj[5]);
		if(p.isZero() || p.isNegative()){
			obj[6] = "Completed";
		}
		else{
			obj[6] = "In Progress";
		}
		return obj;
	}

}
