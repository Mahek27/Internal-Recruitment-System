package com.igate.irs.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.igate.irs.dao.ILoginDAO;
import com.igate.irs.dto.User;
import com.igate.irs.exception.IRSLoginException;

@Component("loginservice")
public class LoginServiceImpl implements ILoginService {
	
	@Autowired
	ILoginDAO logindao;
	
	@Override
	public User isValidUser(User user) throws IRSLoginException {
		return logindao.isValidUser(user);
	}

	

}
