package com.igate.irs.dto;

public class Suggestion {
	
	private String requisitionId;
	private String employeeId;
	
	public Suggestion() 
	{
		
	}
	public Suggestion(String requisitionId, String employeeId) {
		super();
		this.requisitionId = requisitionId;
		this.employeeId = employeeId;
	}
	
	public String getRequisitionId() {
		return requisitionId;
	}

	public void setRequisitionId(String requisitionId) {
		this.requisitionId = requisitionId;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	

	
	
}
