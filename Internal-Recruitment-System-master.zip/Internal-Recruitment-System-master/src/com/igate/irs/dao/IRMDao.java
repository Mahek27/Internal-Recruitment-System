package com.igate.irs.dao;

import java.util.List;

import com.igate.irs.dto.Requisition;
import com.igate.irs.dto.Suggestion;
import com.igate.irs.exception.IRSRMException;

public interface IRMDao {
	public int raiseRequisition(Requisition requisition) throws IRSRMException;
	public List<String> getRMProjects(String rmId) throws IRSRMException;
	public List<Requisition> getAllRequisitions(String rmId) throws IRSRMException;
	public List<Object[]> getSuggestions(String rmId) throws IRSRMException;
	public boolean acceptSuggestion(Suggestion suggestion, String projectId) throws IRSRMException;
	public boolean declineSuggestion(Suggestion suggestion) throws IRSRMException;
	public List<Object[]> getRMEmployeeDetails(String rmId) throws IRSRMException;
	List<Requisition> generateReport(String status, String rmId) throws IRSRMException;
	public boolean changeEmployeeProject(String employeeId) throws IRSRMException;
	
}
