package com.igate.irs.test;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.igate.irs.dao.RMDaoImpl;
import com.igate.irs.exception.IRSRMException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"dispatcher-servlet.xml"})
public class RMGetRMProjectsTest {
	
	@Autowired
	private RMDaoImpl rmDao;

	//giving valid rmID AP835017 who has raised some requisitions
	@Test
	public void test1() {
		System.out.println("in test class1");
		String rmId="AP835017";
		try {
			Assert.assertNotNull(rmDao.getRMProjects(rmId));
		} catch (IRSRMException e) {
			e.printStackTrace();
		}
	}
	
	//giving rmID as CP834586 who is not a RM
	@Test
	public void test2() {
		System.out.println("in test class2");
		String rmId="CP834586";
		try {
			Assert.assertNotNull(rmDao.getRMProjects(rmId));
			Assert.fail("RM ID has not raised any requisitions");
		} catch (IRSRMException e) {
			e.printStackTrace();
		}
	
	}
	
	

}
