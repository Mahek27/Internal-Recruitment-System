package com.igate.irs.util;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:oracle.properties")
@Profile("dev")
public class DBUtility {
	@Value("${driver}")
	private String driver;
	@Value("${url}")
	private String url;
	@Value("${user}")
	private String username;
	@Value("${password}")
	private String password;
	
	@Bean
	@Qualifier("datasource")
	public DataSource getData(){
		DriverManagerDataSource dab = new DriverManagerDataSource();
		dab.setUrl(url);
		dab.setDriverClassName(driver);
		dab.setUsername(username);
		dab.setPassword(password);
		return dab;
	}
}
