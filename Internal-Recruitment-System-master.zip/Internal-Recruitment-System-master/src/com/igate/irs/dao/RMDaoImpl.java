package com.igate.irs.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.igate.irs.dto.Requisition;
import com.igate.irs.dto.Suggestion;
import com.igate.irs.exception.IRSRMException;

@Component("rmDao")
public class RMDaoImpl implements IRMDao{

	@Autowired
	DataSource dataSource;
	
	@Override
	public int raiseRequisition(Requisition requisition) throws IRSRMException {
		int rowsInserted=0;
		int reqIdNum;
		
		try {
			//JdbcTemplate
			JdbcTemplate jdbc = new JdbcTemplate(dataSource);
			
			String genSeqSql="SELECT req_seq.NEXTVAL FROM DUAL";
			reqIdNum = jdbc.queryForObject(genSeqSql, Integer.class);
			
			String strReqId ;
			if(reqIdNum<10){
				strReqId = "RQ" + "00" + reqIdNum;
			}
			else if(reqIdNum<100){
				strReqId = "RQ" + "0" + reqIdNum;
			}
			else {
				strReqId = "RQ" + reqIdNum;
			}
			
			String insertSql="INSERT INTO requisition VALUES(?, ?, ?, SYSDATE, NULL, ?, ?, ?, ?, ?, ?)";
			Object args[] = new Object[9];
			args[0] = strReqId;
			args[1] = requisition.getRmId();
			args[2] = requisition.getProjectId();
			args[3] = "OPEN";
			args[4] = requisition.getVacancyName();
			args[5] = requisition.getSkill();
			args[6] = requisition.getDomain();
			args[7] = requisition.getNumberRequired();
			args[8] = 0;
			
			rowsInserted = jdbc.update(insertSql, args);
			
		} catch (DataAccessException e) {
			e.printStackTrace();
			throw new IRSRMException(e.getMessage());
		}
		return rowsInserted;
	}

	@Override
	public List<String> getRMProjects(String rmId) throws IRSRMException {
		try {
			//JdbcTemplate
			JdbcTemplate jdbc = new JdbcTemplate(dataSource);
			
			//Query to retrieve project Ids from project table for the given RM ID
			String selectSQL = "SELECT project_id, project_name, domain FROM project WHERE rm_id='"+rmId+"' AND END_DATE > SYSDATE";
			
			List<String> projects = jdbc.query(selectSQL, new ProjectRowMapper());
			System.out.println(projects);
			
			if(projects.size()>0)
				return projects;
			else
				return null;
			
		} catch (DataAccessException e) {
			e.printStackTrace();
			throw new IRSRMException(e.getMessage());
		}
	}

	@Override
	public List<Requisition> getAllRequisitions(String rmId) throws IRSRMException {
		try {
			//JdbcTemplate
			JdbcTemplate jdbc = new JdbcTemplate(dataSource);
			
			//Query to retrieve requisitions from requisition table for the given RM ID
			String selectSQL = "SELECT * FROM requisition WHERE rm_id='"+rmId+"'";
			List<Requisition> requistionList = jdbc.query(selectSQL, new RequisitionRowMapper());
			
			System.out.println(requistionList);
			
			if(requistionList.size()>0)
				return requistionList;
			else
				return null;
			
		} catch (DataAccessException e) {
			e.printStackTrace();
			throw new IRSRMException(e.getMessage());
		}
	}

	@Override
	public List<Object[]> getSuggestions(String rmId) throws IRSRMException {
		try {
			//JdbcTemplate
			JdbcTemplate jdbc = new JdbcTemplate(dataSource);
			
			//Query to retrieve suggestions from requisition,suggestions,employee table for the given RM ID
			String selectSQL = "select r.project_id, s.employee_id, e.employee_name, e.project_id, e.domain, e.skill, s.requisition_id from employee e, suggestions s, requisition r where s.REQUISITION_ID = r.REQUISITION_ID and s.EMPLOYEE_ID = e.EMPLOYEE_ID and r.RM_ID ='"+rmId+"'";
			List<Object[]> suggestions = jdbc.query(selectSQL, new SuggestionRowMapper());
			
			if(suggestions.size()>0)
				return suggestions;
			else
				return null;
		} catch (DataAccessException e) {
			e.printStackTrace();
			throw new IRSRMException(e.getMessage());
		}
	}

	@Override
	public boolean acceptSuggestion(Suggestion suggestion, String projectId)
			throws IRSRMException {
		boolean flag = false;
		
		try {
			//JdbcTemplate
			JdbcTemplate jdbc = new JdbcTemplate(dataSource);
			
			String updateRequisitionSql = "UPDATE requisition SET number_accepted=number_accepted + 1 WHERE requisition_id=?";
			int updatedRequisition = jdbc.update(updateRequisitionSql, suggestion.getRequisitionId());	
			
			String updateEmployeeSql = "UPDATE employee SET project_id=? WHERE employee_id=?";
			int updatedEmployee = jdbc.update(updateEmployeeSql, projectId, suggestion.getEmployeeId());
			
			String removeSql = "delete from suggestions where employee_id=?";
			int removedSuggestion = jdbc.update(removeSql, suggestion.getEmployeeId());
			
			String selectNumRequiredSql = "SELECT number_required FROM requisition where requisition_id=?";
			int numRequired = jdbc.queryForObject(selectNumRequiredSql, Integer.class, suggestion.getRequisitionId());
			
			String selectNumAcceptedSql = "SELECT number_accepted FROM requisition where requisition_id=?";
			int numAccepted = jdbc.queryForObject(selectNumAcceptedSql, Integer.class, suggestion.getRequisitionId());
			
			if(numAccepted==numRequired){
				String updateStatus = "UPDATE requisition SET current_status='CLOSED', date_closed=SYSDATE WHERE requisition_id=?";
				int status = jdbc.update(updateStatus, suggestion.getRequisitionId());
				if(status==1){
					System.out.println("requistion closed::::"+suggestion.getRequisitionId());
				}
				else{
					System.out.println("requistion still open::::"+suggestion.getRequisitionId());
				}
			}
			
			System.out.println(updatedRequisition+","+","+removedSuggestion+","+updatedEmployee);
			if(updatedRequisition==1 && removedSuggestion==1 && updatedEmployee==1){
				flag=true;
			}
			else{
				System.out.println("ERROR::Suggestion not accepted");
				throw new IRSRMException("ERROR::Suggestion not accepted");
			}
		} catch (DataAccessException e) {
			e.printStackTrace();
			throw new IRSRMException(e.getMessage());
		}
		
		return flag;
	}

	@Override
	public boolean declineSuggestion(Suggestion suggestion) throws IRSRMException {
		boolean flag = false;
		try {
			//JdbcTemplate
			JdbcTemplate jdbc = new JdbcTemplate(dataSource);
			
			String removeSql = "delete from suggestions where requisition_id=? and employee_id=?";
			int removedSuggestion = jdbc.update(removeSql, suggestion.getRequisitionId(),suggestion.getEmployeeId());
			
			if(removedSuggestion==1){
				flag = true;
			}
			
		} catch (DataAccessException e) {
			e.printStackTrace();
			throw new IRSRMException(e.getMessage());
		}
		
		return flag;
	}

	
	@Override
	public List<Object[]> getRMEmployeeDetails(String rmId) throws IRSRMException {
		try {
			//JdbcTemplate
			JdbcTemplate jdbc = new JdbcTemplate(dataSource);
			
			//Query to retrieve employees under the RM's projects from employee table for the given RM ID
			String selectSQL = "SELECT e.employee_id, e.employee_name, p.project_id, p.project_name, p.start_date, p.end_date FROM  project p, employee e WHERE e.project_id=p.project_id AND p.rm_id='"+rmId+"'";
			
			List<Object[]> employeeList = jdbc.query(selectSQL, new RMEmployeeRowMapper());
			
			if(employeeList.size()>0)
				return employeeList;
			else
				return null;
		} catch (DataAccessException e) {
			e.printStackTrace();
			throw new IRSRMException(e.getMessage());
		}
	}

	
	@Override
	public List<Requisition> generateReport(String status, String rmId) throws IRSRMException {
		try {
			//JdbcTemplate
			JdbcTemplate jdbc = new JdbcTemplate(dataSource);
			
			//Query to retrieve requisitions from requisition table for the given RM ID
			String selectSQL = "SELECT * FROM requisition WHERE rm_id='"+rmId+"' AND current_status ='"+status+"'";
			List<Requisition> requistionList = jdbc.query(selectSQL, new RequisitionRowMapper());
			
			System.out.println(requistionList);
			if(requistionList.size()>0)
				return requistionList;
			else
				return null;
		} catch (DataAccessException e) {
			e.printStackTrace();
			throw new IRSRMException(e.getMessage());
		}
	}

	
	@Override
	public boolean changeEmployeeProject(String employeeId) throws IRSRMException {
		boolean flag = false;
		try {
			//JdbcTemplate
			JdbcTemplate jdbc = new JdbcTemplate(dataSource);
			
			String updateProjectIdSql = "UPDATE employee SET project_id='RMG' WHERE employee_id=?";
			int updated = jdbc.update(updateProjectIdSql, employeeId);
			
			if(updated==1){
				flag = true;
			}
			
		} catch (DataAccessException e) {
			e.printStackTrace();
			throw new IRSRMException(e.getMessage());
		}
		return flag;
	}

	
}
