package com.igate.irs.test;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.igate.irs.dao.RMGEDaoImpl;
import com.igate.irs.exception.IRSRMGEException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"dispatcher-servlet.xml"})
@ActiveProfiles("oracle")
public class RMGEViewRequisitionsTest {
	
	@Autowired
	private RMGEDaoImpl rmgeDao;

	@Test
	public void test1() {
		System.out.println("in test class1");
		try {
			Assert.assertNotNull(rmgeDao.viewRequestions());
		} catch (IRSRMGEException e) {
			e.printStackTrace();
		}
	}
}
