package com.igate.irs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.igate.irs.dao.IRMDao;
import com.igate.irs.dto.Requisition;
import com.igate.irs.dto.Suggestion;
import com.igate.irs.exception.IRSRMException;

@Component("rmService")
public class RMServiceImpl implements IRMService{

	@Autowired
	IRMDao rmDao;
	
	@Override
	public int raiseRequisition(Requisition requisition) throws IRSRMException {
		return rmDao.raiseRequisition(requisition);
	}
	@Override
	public List<String> getRMProjects(String rmId) throws IRSRMException {
		return rmDao.getRMProjects(rmId);
	}
	@Override
	public List<Requisition> getAllRequisitions(String rmId)
			throws IRSRMException {
		return rmDao.getAllRequisitions(rmId);
	}
	@Override
	public List<Object[]> getSuggestions(String rmId) throws IRSRMException {
		return rmDao.getSuggestions(rmId);
	}
	@Override
	public boolean acceptSuggestion(Suggestion suggestion, String projectId) throws IRSRMException{
	
		return rmDao.acceptSuggestion(suggestion, projectId);
	}
	@Override
	public boolean declineSuggestion(Suggestion suggestion) throws IRSRMException {
		return rmDao.declineSuggestion(suggestion);
	}
	@Override
	public List<Object[]> getRMEmployeeDetails(String rmId) throws IRSRMException {
		return rmDao.getRMEmployeeDetails(rmId);
	}
	@Override
	public List<Requisition> generateReport(String status, String rmId)
			throws IRSRMException {
		return rmDao.generateReport(status, rmId);
	}
	@Override
	public boolean changeEmployeeProject(String employeeId) throws IRSRMException {
		return rmDao.changeEmployeeProject(employeeId);
	}

	
}
