package com.igate.irs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class SuggestionRowMapper implements RowMapper<Object[]> {

	@Override
	public Object[] mapRow(ResultSet rst, int num) throws SQLException {
		Object suggestion[] = new Object[7];
		suggestion[0] = rst.getString("employee_id");
		suggestion[1] = rst.getString("employee_name");
		suggestion[2] = rst.getString(4);
		suggestion[3] = rst.getString("domain");
		suggestion[4] = rst.getString("skill");
		suggestion[5] = rst.getString("requisition_id");
		suggestion[6] = rst.getString(1);
		return suggestion;
	}

}
