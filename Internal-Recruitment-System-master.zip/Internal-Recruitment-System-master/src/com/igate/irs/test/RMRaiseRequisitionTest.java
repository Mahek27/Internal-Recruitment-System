package com.igate.irs.test;

import static junit.framework.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.igate.irs.dao.RMDaoImpl;
import com.igate.irs.dto.Requisition;
import com.igate.irs.exception.IRSRMException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"dispatcher-servlet.xml"})
public class RMRaiseRequisitionTest {
	
	@Autowired
	private RMDaoImpl rmDao;

	//giving valid rmID ED871255 who has raised some requisitions
	@Test
	public void test1() {
		System.out.println("in test class1");
		Requisition req = new Requisition();
		req.setRmId("ED871255");
		req.setDomain("VnV");
		req.setNumberRequired("2");
		req.setProjectId("P01");
		req.setSkill("Level 5");
		req.setVacancyName("Testing Engineer");
		try {
			assertNotNull(rmDao.raiseRequisition(req));
		} catch (IRSRMException e) {
			e.printStackTrace();
		}
	}
	

}
