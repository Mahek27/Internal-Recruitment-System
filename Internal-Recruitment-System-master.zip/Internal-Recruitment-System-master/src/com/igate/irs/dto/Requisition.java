package com.igate.irs.dto;

import java.time.LocalDate;

public class Requisition {

	private String requisitionId;
	private String rmId;
	private String projectId;
	private LocalDate dateCreated;
	private LocalDate dateClosed;
	private String currentStatus;
	private String vacancyName;
	private String skill;
	private String domain;
	private String numberRequired;
	private String numberAccepted;


	public Requisition() {

	}


	public Requisition(String requisitionId, String rmId, String projectId,
			LocalDate dateCreated, LocalDate dateClosed, String currentStatus,
			String vacancyName, String skill, String domain,
			String numberRequired, String numberAccepted) {
		super();
		this.requisitionId = requisitionId;
		this.rmId = rmId;
		this.projectId = projectId;
		this.dateCreated = dateCreated;
		this.dateClosed = dateClosed;
		this.currentStatus = currentStatus;
		this.vacancyName = vacancyName;
		this.skill = skill;
		this.domain = domain;
		this.numberRequired = numberRequired;
		this.numberAccepted = numberAccepted;
	}


	public String getRequisitionId() {
		return requisitionId;
	}


	public void setRequisitionId(String requisitionId) {
		this.requisitionId = requisitionId;
	}


	public String getRmId() {
		return rmId;
	}


	public void setRmId(String rmId) {
		this.rmId = rmId;
	}


	public String getProjectId() {
		return projectId;
	}


	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}


	public LocalDate getDateCreated() {
		return dateCreated;
	}


	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}


	public LocalDate getDateClosed() {
		return dateClosed;
	}


	public void setDateClosed(LocalDate dateClosed) {
		this.dateClosed = dateClosed;
	}


	public String getCurrentStatus() {
		return currentStatus;
	}


	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}


	public String getVacancyName() {
		return vacancyName;
	}


	public void setVacancyName(String vacancyName) {
		this.vacancyName = vacancyName;
	}


	public String getSkill() {
		return skill;
	}


	public void setSkill(String skill) {
		this.skill = skill;
	}


	public String getDomain() {
		return domain;
	}


	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getNumberRequired() {
		return numberRequired;
	}


	public void setNumberRequired(String numberRequired) {
		this.numberRequired = numberRequired;
	}


	public String getNumberAccepted() {
		return numberAccepted;
	}


	public void setNumberAccepted(String numberAccepted) {
		this.numberAccepted = numberAccepted;
	}


	@Override
	public String toString() {
		return "Requisition [requisitionId=" + requisitionId + ", rmId=" + rmId
				+ ", projectId=" + projectId + ", dateCreated=" + dateCreated
				+ ", dateClosed=" + dateClosed + ", currentStatus="
				+ currentStatus + ", vacancyName=" + vacancyName + ", skill="
				+ skill + ", domain=" + domain + ", numberRequired="
				+ numberRequired + ", numberAccepted=" + numberAccepted + "]";
	}


	

}
