package com.igate.irs.dao;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.igate.irs.dto.Requisition;

public class RequisitionRowMapper implements RowMapper<Requisition> {

	@Override
	public Requisition mapRow(ResultSet rst, int num) throws SQLException {
		Requisition req = new Requisition();
		req.setRequisitionId(rst.getString("requisition_id"));
		req.setProjectId(rst.getString("project_id"));
		req.setSkill(rst.getString("skill"));
		req.setDomain(rst.getString("domain"));
		req.setNumberRequired(rst.getString("number_required"));
		req.setNumberAccepted(rst.getString("number_accepted"));
		req.setCurrentStatus(rst.getString("CURRENT_STATUS"));
		req.setRmId(rst.getString("rm_id"));
		req.setVacancyName(rst.getString("vacancy_name"));
		req.setDateCreated(rst.getDate("date_created").toLocalDate());
		
		Date closedDate = rst.getDate("date_closed");
		if(closedDate!=null)
			req.setDateClosed(closedDate.toLocalDate());
		else
			req.setDateClosed(null);
		
		return req;
	}

}
