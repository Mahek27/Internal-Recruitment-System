package com.igate.irs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.igate.irs.dao.RMGEDaoImpl;
import com.igate.irs.dto.Requisition;
import com.igate.irs.dto.Suggestion;
import com.igate.irs.exception.IRSRMGEException;

@Component("rmgeService")
public class RMGEServiceImpl implements IRMGEService {
	@Autowired
	RMGEDaoImpl rmgedao;
	@Override
	public List<Requisition> viewRequestions() throws IRSRMGEException {
		return rmgedao.viewRequestions();
	}


	@Override
	public boolean suggestEmployee(Suggestion suggestion) throws IRSRMGEException {
		return rmgedao.suggestEmployee(suggestion);
	}



	@Override
	public List<Requisition> generateReport(String status)
			throws IRSRMGEException {
		return rmgedao.generateReport(status);
	}


	@Override
	public List<Object[]> viewSearch(String rskill, String rdomain,
			String rid) throws IRSRMGEException {
		return rmgedao.viewSearch(rskill, rdomain, rid);
	}

}
