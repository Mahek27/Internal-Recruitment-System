package com.igate.irs.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.igate.irs.dto.User;
import com.igate.irs.exception.IRSLoginException;
import com.igate.irs.service.ILoginService;

@Controller
@RequestMapping(value="/Login")
@SessionAttributes({"account"})
public class LoginController {
	@Autowired
	ILoginService loginservice;
	@Autowired
	HttpSession session;

	@RequestMapping(value="/loginPage",method=RequestMethod.GET)
	public String LoginPage(Map<String,Object> model)
	{
		User users=new User();
		model.put("loginForm",users);
		return "login";
	}


	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String Login(@ModelAttribute("loginForm") User user,
			BindingResult result,
			Model model,
			@RequestParam("userId") String userId,
			@RequestParam("password") String password,
			@RequestParam("role") String urole,
			HttpSession session,HttpServletRequest request)
	{

		if(result.hasErrors())
		{
			return  "redirect:/Login/loginPage";
		}
		else if(user!=null)
		{
			System.out.println(user);
			try {
				user = loginservice.isValidUser(user);
				if (user!=null)
				{
					System.out.println("Valid user");

					session.invalidate();
					session = request.getSession();

					session.setAttribute("validUser", "true");
					session.setAttribute("username", user.getUserName());
					session.setAttribute("userid", user.getUserId());
					session.setAttribute("role", user.getRole());
					//model.addAttribute("data", user);

					if(urole.equals("rm"))
					{
						return  "redirect:/RM/RaiseRequistion";
					}
					else
					{
						return "redirect:/RMGE/viewRequisitions";
					}
				}
				else
				{
					model.addAttribute("validUser", "false");
					User users=new User();
					model.addAttribute("loginForm",users);
					return "login";
				}
			} catch (IRSLoginException e) {
				model.addAttribute("msg","Technical Problem..Please Try Later!!");
				return "error";
			}
		}
		return "error";
	}

	@RequestMapping(value="/redirect",method=RequestMethod.GET)
	public  String redirect(@RequestParam("role") String role)
	{
		if(role.equals("rm"))
		{
			return  "redirect:/RM/RaiseRequistion";
		}
		else
		{
			return "redirect:/RMGE/viewRequisitions";
		}

	}


	@RequestMapping(value="/logout",method=RequestMethod.GET)
	public  String Logout(HttpSession session,HttpServletRequest request)
	{
		session=request.getSession(false);
		session.invalidate();
		return "redirect:/Login/loginPage";

	}
}
